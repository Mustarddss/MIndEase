package com.example.afterfinishingthesurvey;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Chat Icon - Already on Chat Page
        ImageView navChat = findViewById(R.id.nav_chat);
        navChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // No action needed as we're on the Chat Page
            }
        });

        // Calendar Icon - Navigate to Schedule Activity
        ImageView navCalendar = findViewById(R.id.nav_calendar);
        navCalendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ActivitySchedule.class);
                startActivity(intent);
            }
        });

        // Group Icon - Navigate to Group Activity
        ImageView navGroup = findViewById(R.id.nav_group);
        navGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, GroupSession.class);
                startActivity(intent);
            }
        });

        // Menu Icon - Navigate to Menu Activity
        ImageView navMenu = findViewById(R.id.nav_menu);
        navMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, MoreFeatures.class);
                startActivity(intent);
            }
        });
    }
}
