package com.example.afterfinishingthesurvey;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class MoreFeatures extends AppCompatActivity {

    private Button subscriptionButton, yourTherapist, myAccountButton, faqButton, contactUsButton, termsButton, privacyButton, logoutButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.more_features);

        // Initialize Buttons
        subscriptionButton = findViewById(R.id.button_subscription);
        yourTherapist = findViewById(R.id.your_therapist);
        myAccountButton = findViewById(R.id.button_my_account);
        faqButton = findViewById(R.id.button_faq);
        contactUsButton = findViewById(R.id.button_contact_us);
        termsButton = findViewById(R.id.button_terms_conditions);
        privacyButton = findViewById(R.id.button_privacy_policy);
        logoutButton = findViewById(R.id.button_logout);

        // Set Click Listeners for navigation
       // subscriptionButton.setOnClickListener(v -> openActivity(SubscriptionActivity.class));
        yourTherapist.setOnClickListener(v -> openActivity(YourTherapist.class));
        // myAccountButton.setOnClickListener(v -> openActivity(MyAccountActivity.class));
       // faqButton.setOnClickListener(v -> openActivity(FaqActivity.class));
       //contactUsButton.setOnClickListener(v -> openActivity(ContactUsActivity.class));
       //termsButton.setOnClickListener(v -> openActivity(TermsActivity.class));
      //privacyButton.setOnClickListener(v -> openActivity(PrivacyPolicyActivity.class));

        // Logout Button Click
        logoutButton.setOnClickListener(v -> {
            // Perform logout action (clear session, navigate to login screen, etc.)
            Intent intent = new Intent(MoreFeatures.this, MoreFeatures.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);
            finish();
        });
    }

    private void openActivity(Class<?> activityClass) {
        Intent intent = new Intent(this, activityClass);
        startActivity(intent);
    }
}
