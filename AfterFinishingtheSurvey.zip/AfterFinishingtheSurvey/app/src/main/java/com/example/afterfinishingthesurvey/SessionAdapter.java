package com.example.afterfinishingthesurvey;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class SessionAdapter extends RecyclerView.Adapter<SessionAdapter.ViewHolder> {
    private final List<Session> sessionList;
    private final OnSessionClickListener listener;

    // Interface for handling click events on a session item
    public interface OnSessionClickListener {
        void onSessionClick(Session session);
    }

    // Constructor to initialize the session list and click listener
    public SessionAdapter(List<Session> sessionList, OnSessionClickListener listener) {
        this.sessionList = sessionList;
        this.listener = listener;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate the session_item layout
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.session_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Bind the session data to the ViewHolder
        Session session = sessionList.get(position);
        holder.sessionTitle.setText(session.getTitle());
        holder.sessionIcon.setImageResource(session.getIconResId());

        // Set click listener for the session item
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onSessionClick(session);
            }
        });
    }

    @Override
    public int getItemCount() {
        return sessionList.size(); // Return the total number of items
    }

    // ViewHolder class to hold references to the views for each item
    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView sessionTitle;
        ImageView sessionIcon;

        ViewHolder(View itemView) {
            super(itemView);
            sessionTitle = itemView.findViewById(R.id.sessionTitle); // Ensure ID matches session_item.xml
            sessionIcon = itemView.findViewById(R.id.sessionIcon);  // Ensure ID matches session_item.xml
        }
    }
}

