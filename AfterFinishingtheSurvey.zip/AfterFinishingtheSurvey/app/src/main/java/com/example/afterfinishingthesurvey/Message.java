package com.example.afterfinishingthesurvey;


public class Message {
    private String sender;
    private String text;
    private int profileIcon;

    public Message(String sender, String text, int profileIcon) {
        this.sender = sender;
        this.text = text;
        this.profileIcon = profileIcon;
    }

    public String getSender() {
        return sender;
    }

    public String getText() {
        return text;
    }

    public int getProfileIcon() {
        return profileIcon;
    }
}
