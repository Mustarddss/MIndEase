package com.example.afterfinishingthesurvey;

import android.content.Intent;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.ArrayList;
import java.util.List;

public class GroupSession extends AppCompatActivity {
    private RecyclerView recyclerView;
    private SessionAdapter sessionAdapter;
    private List<Session> sessionList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_session);
        findViewById(R.id.backButton).setOnClickListener(v -> {
            onBackPressed(); // back navigation
        });

        recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        sessionList = new ArrayList<>();
        sessionList.add(new Session("Talk about Anxiety", R.drawable.anxiety_icon));
        sessionList.add(new Session("Talk about Depression", R.drawable.depression_icon));
        sessionList.add(new Session("Talk about Academic Issues", R.drawable.academic_icon));
        sessionList.add(new Session("Talk about Work Issues", R.drawable.work_icon));
        sessionList.add(new Session("Talk about Grief or Loss", R.drawable.grief_icon));

        sessionAdapter = new SessionAdapter(sessionList, session -> {
            Intent intent = new Intent(GroupSession.this, ChatActivity.class);
            intent.putExtra("SESSION_TITLE", session.getTitle());
            startActivity(intent);
        });

        recyclerView.setAdapter(sessionAdapter);
    }
}




