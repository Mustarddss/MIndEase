package com.example.afterfinishingthesurvey;

import android.app.TimePickerDialog;
import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

public class ActivitySchedule extends AppCompatActivity {

    private String selectedDate = "";
    private HashMap<String, ArrayList<String>> scheduleMap; // Stores schedules by date
    private ArrayAdapter<String> scheduleAdapter;

    // Maximum number of schedules allowed per day
    private static final int MAX_SCHEDULES_PER_DAY = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);

        CalendarView calendarView = findViewById(R.id.calendarView);
        Button addScheduleButton = findViewById(R.id.addScheduleButton);
        EditText scheduleInput = findViewById(R.id.scheduleInput);
        ListView scheduleListView = findViewById(R.id.scheduleListView);
        TextView scheduleStatus = findViewById(R.id.scheduleStatus);
        findViewById(R.id.backButton).setOnClickListener(v -> {
            onBackPressed(); // Ensures correct back navigation
        });

        // Initialize the schedule map and adapter
        scheduleMap = new HashMap<>();
        scheduleAdapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        scheduleListView.setAdapter(scheduleAdapter);

        // Get the currently selected date
        selectedDate = getCurrentDate(calendarView);

        // Update selected date when the user clicks a new date
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            selectedDate = dayOfMonth + "/" + (month + 1) + "/" + year;
            updateScheduleDisplay(selectedDate, scheduleStatus);
        });

        // Add schedule button click listener
        addScheduleButton.setOnClickListener(v -> {
            String scheduleText = scheduleInput.getText().toString().trim();
            if (scheduleText.isEmpty()) {
                Toast.makeText(ActivitySchedule.this, "Please enter a schedule description!", Toast.LENGTH_SHORT).show();
                return;
            }

            // Check if the selected date has reached the maximum schedule limit
            ArrayList<String> schedulesForDate = scheduleMap.get(selectedDate);
            if (schedulesForDate != null && schedulesForDate.size() >= MAX_SCHEDULES_PER_DAY) {
                Toast.makeText(ActivitySchedule.this, "You cannot book more schedules for this day. Please choose another date.", Toast.LENGTH_SHORT).show();
                return;
            }

            // Show a TimePickerDialog to select a time
            Calendar currentTime = Calendar.getInstance();
            int hour = currentTime.get(Calendar.HOUR_OF_DAY);
            int minute = currentTime.get(Calendar.MINUTE);

            TimePickerDialog timePickerDialog = new TimePickerDialog(ActivitySchedule.this,
                    (timePicker, selectedHour, selectedMinute) -> {
                        // Convert to AM/PM format
                        String amPm = (selectedHour >= 12) ? "PM" : "AM";
                        int hourIn12Format = (selectedHour == 0 || selectedHour == 12) ? 12 : selectedHour % 12;

                        String time = String.format("%02d:%02d %s", hourIn12Format, selectedMinute, amPm);
                        String fullDateTime = selectedDate + " " + time + " - " + scheduleText;

                        // Add schedule to the map
                        scheduleMap.putIfAbsent(selectedDate, new ArrayList<>());
                        scheduleMap.get(selectedDate).add(fullDateTime);

                        updateScheduleDisplay(selectedDate, scheduleStatus);
                        scheduleInput.setText("");
                        Toast.makeText(ActivitySchedule.this, "Schedule added!", Toast.LENGTH_SHORT).show();
                    }, hour, minute, false); // Set to false for 12-hour format with AM/PM

            timePickerDialog.show();
        });
    }

    // Helper method to get the current date
    private String getCurrentDate(CalendarView calendarView) {
        long date = calendarView.getDate();
        Calendar calendar = Calendar.getInstance();
        calendar.setTimeInMillis(date);
        return calendar.get(Calendar.DAY_OF_MONTH) + "/" +
                (calendar.get(Calendar.MONTH) + 1) + "/" +
                calendar.get(Calendar.YEAR);
    }

    // Updates the schedule display for the selected date
    private void updateScheduleDisplay(String date, TextView scheduleStatus) {
        ArrayList<String> schedulesForDate = scheduleMap.get(date);
        if (schedulesForDate == null || schedulesForDate.isEmpty()) {
            scheduleAdapter.clear();
            scheduleStatus.setText("No schedules for this day.");
        } else {
            scheduleAdapter.clear();
            scheduleAdapter.addAll(schedulesForDate);
            scheduleAdapter.notifyDataSetChanged();

            // Show status message
            if (schedulesForDate.size() >= MAX_SCHEDULES_PER_DAY) {
                scheduleStatus.setText("Full schedule for this day (Max 2). You cannot book more on this date.");
            } else {
                scheduleStatus.setText("Schedules for this day:");
            }
        }
    }
}
