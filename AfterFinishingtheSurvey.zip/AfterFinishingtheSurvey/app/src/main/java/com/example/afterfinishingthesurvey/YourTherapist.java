package com.example.afterfinishingthesurvey;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class YourTherapist extends AppCompatActivity {

    private LinearLayout reviewsContainer;
    private EditText reviewEditText;
    private RatingBar ratingBar;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_yourtherapist);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        // Initialize UI elements
        reviewsContainer = findViewById(R.id.recycler_view_reviews);
        reviewEditText = findViewById(R.id.edit_text_review);
        ratingBar = findViewById(R.id.rating_bar);
        Button submitReviewButton = findViewById(R.id.button_submit_review);

        // Add pre-existing reviews (example)
        addReview("⭐⭐⭐⭐⭐", "Great Service", "I cannot express how grateful I am for the guidance and support I've received. Highly recommended!");

        // Handle new review submission
        submitReviewButton.setOnClickListener(v -> {
            float rating = ratingBar.getRating();
            String reviewText = reviewEditText.getText().toString();

            if (rating == 0 || reviewText.isEmpty()) {
                Toast.makeText(this, "Please provide a rating and review", Toast.LENGTH_SHORT).show();
            } else {
                // Format rating into stars
                StringBuilder stars = new StringBuilder();
                for (int i = 0; i < (int) rating; i++) {
                    stars.append("⭐");
                }

                // Add the new review
                addReview(stars.toString(), "User Review", reviewText);

                // Clear input fields
                ratingBar.setRating(0);
                reviewEditText.setText("");

                Toast.makeText(this, "Review submitted successfully!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addReview(String ratingStars, String title, String reviewText) {
        // Inflate the review layout dynamically
        View reviewView = LayoutInflater.from(this).inflate(R.layout.review_item, reviewsContainer, false);

        TextView ratingTextView = reviewView.findViewById(R.id.text_rating);
        TextView titleTextView = reviewView.findViewById(R.id.text_review_title);
        TextView reviewTextView = reviewView.findViewById(R.id.text_review_body);

        ratingTextView.setText(ratingStars);
        titleTextView.setText(title);
        reviewTextView.setText(reviewText);

        // Add the new review to the container
        reviewsContainer.addView(reviewView, 0);
    }
}
